﻿
namespace School
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.regex = new System.Windows.Forms.GroupBox();
            this.reg_no = new System.Windows.Forms.ComboBox();
            this.delete2 = new System.Windows.Forms.Button();
            this.clear2 = new System.Windows.Forms.Button();
            this.update2 = new System.Windows.Forms.Button();
            this.reg2 = new System.Windows.Forms.Button();
            this.load_combo = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.G_name = new System.Windows.Forms.TextBox();
            this.G_nic = new System.Windows.Forms.TextBox();
            this.G_co_no = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.M_name = new System.Windows.Forms.TextBox();
            this.M_nic = new System.Windows.Forms.TextBox();
            this.M_co_no = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.Fa_name = new System.Windows.Forms.TextBox();
            this.Fa_nic = new System.Windows.Forms.TextBox();
            this.Fa_co_no = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.h_no = new System.Windows.Forms.TextBox();
            this.m_no = new System.Windows.Forms.TextBox();
            this.email = new System.Windows.Forms.TextBox();
            this.address = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.DOB = new System.Windows.Forms.DateTimePicker();
            this.female = new System.Windows.Forms.RadioButton();
            this.male = new System.Windows.Forms.RadioButton();
            this.L_name = new System.Windows.Forms.TextBox();
            this.F_name = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Logout_link = new System.Windows.Forms.LinkLabel();
            this.Exit_link = new System.Windows.Forms.LinkLabel();
            this.gender = new System.Windows.Forms.Label();
            this.regex.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // regex
            // 
            this.regex.BackColor = System.Drawing.SystemColors.HighlightText;
            this.regex.Controls.Add(this.reg_no);
            this.regex.Controls.Add(this.delete2);
            this.regex.Controls.Add(this.clear2);
            this.regex.Controls.Add(this.update2);
            this.regex.Controls.Add(this.reg2);
            this.regex.Controls.Add(this.load_combo);
            this.regex.Controls.Add(this.groupBox4);
            this.regex.Controls.Add(this.groupBox3);
            this.regex.Controls.Add(this.groupBox2);
            this.regex.Font = new System.Drawing.Font("Sitka Heading", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.regex.ForeColor = System.Drawing.SystemColors.ControlText;
            this.regex.Location = new System.Drawing.Point(12, 56);
            this.regex.Name = "regex";
            this.regex.Size = new System.Drawing.Size(1270, 625);
            this.regex.TabIndex = 0;
            this.regex.TabStop = false;
            this.regex.Text = "Student Registration";
            this.regex.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // reg_no
            // 
            this.reg_no.Font = new System.Drawing.Font("Sitka Heading", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.reg_no.FormattingEnabled = true;
            this.reg_no.Location = new System.Drawing.Point(195, 44);
            this.reg_no.Name = "reg_no";
            this.reg_no.Size = new System.Drawing.Size(188, 31);
            this.reg_no.TabIndex = 7;
            this.reg_no.SelectedIndexChanged += new System.EventHandler(this.reg_no_SelectedIndexChanged);
            // 
            // delete2
            // 
            this.delete2.Font = new System.Drawing.Font("Sitka Heading", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.delete2.Location = new System.Drawing.Point(151, 582);
            this.delete2.Name = "delete2";
            this.delete2.Size = new System.Drawing.Size(75, 34);
            this.delete2.TabIndex = 6;
            this.delete2.Text = "Delete";
            this.delete2.UseVisualStyleBackColor = true;
            this.delete2.Click += new System.EventHandler(this.delete2_Click);
            // 
            // clear2
            // 
            this.clear2.Font = new System.Drawing.Font("Sitka Heading", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.clear2.Location = new System.Drawing.Point(44, 582);
            this.clear2.Name = "clear2";
            this.clear2.Size = new System.Drawing.Size(75, 34);
            this.clear2.TabIndex = 5;
            this.clear2.Text = "Clear";
            this.clear2.UseVisualStyleBackColor = true;
            this.clear2.Click += new System.EventHandler(this.clear2_Click);
            // 
            // update2
            // 
            this.update2.Font = new System.Drawing.Font("Sitka Heading", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.update2.Location = new System.Drawing.Point(1171, 582);
            this.update2.Name = "update2";
            this.update2.Size = new System.Drawing.Size(75, 34);
            this.update2.TabIndex = 4;
            this.update2.Text = "Update";
            this.update2.UseVisualStyleBackColor = true;
            this.update2.Click += new System.EventHandler(this.update2_Click);
            // 
            // reg2
            // 
            this.reg2.Font = new System.Drawing.Font("Sitka Heading", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.reg2.Location = new System.Drawing.Point(1067, 582);
            this.reg2.Name = "reg2";
            this.reg2.Size = new System.Drawing.Size(90, 34);
            this.reg2.TabIndex = 3;
            this.reg2.Text = "Register";
            this.reg2.UseVisualStyleBackColor = true;
            this.reg2.Click += new System.EventHandler(this.reg2_Click);
            // 
            // load_combo
            // 
            this.load_combo.AutoSize = true;
            this.load_combo.Font = new System.Drawing.Font("Sitka Small", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.load_combo.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.load_combo.Location = new System.Drawing.Point(40, 41);
            this.load_combo.Name = "load_combo";
            this.load_combo.Size = new System.Drawing.Size(69, 24);
            this.load_combo.TabIndex = 0;
            this.load_combo.Text = "Reg No";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.groupBox7);
            this.groupBox4.Controls.Add(this.groupBox6);
            this.groupBox4.Controls.Add(this.groupBox5);
            this.groupBox4.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.groupBox4.Location = new System.Drawing.Point(690, 14);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(574, 562);
            this.groupBox4.TabIndex = 2;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Gardian Details";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.G_name);
            this.groupBox7.Controls.Add(this.G_nic);
            this.groupBox7.Controls.Add(this.G_co_no);
            this.groupBox7.Controls.Add(this.label17);
            this.groupBox7.Controls.Add(this.label18);
            this.groupBox7.Controls.Add(this.label19);
            this.groupBox7.Location = new System.Drawing.Point(39, 369);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(517, 170);
            this.groupBox7.TabIndex = 23;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Gardian\'s Deatils";
            // 
            // G_name
            // 
            this.G_name.Location = new System.Drawing.Point(195, 21);
            this.G_name.Multiline = true;
            this.G_name.Name = "G_name";
            this.G_name.Size = new System.Drawing.Size(316, 63);
            this.G_name.TabIndex = 22;
            // 
            // G_nic
            // 
            this.G_nic.Location = new System.Drawing.Point(195, 91);
            this.G_nic.Name = "G_nic";
            this.G_nic.Size = new System.Drawing.Size(171, 31);
            this.G_nic.TabIndex = 21;
            // 
            // G_co_no
            // 
            this.G_co_no.Location = new System.Drawing.Point(195, 133);
            this.G_co_no.MaxLength = 10;
            this.G_co_no.Name = "G_co_no";
            this.G_co_no.Size = new System.Drawing.Size(171, 31);
            this.G_co_no.TabIndex = 20;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Sitka Small", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label17.Location = new System.Drawing.Point(30, 135);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(146, 24);
            this.label17.TabIndex = 13;
            this.label17.Text = "Contact Number";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Sitka Small", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label18.Location = new System.Drawing.Point(30, 98);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(41, 24);
            this.label18.TabIndex = 12;
            this.label18.Text = "NIC";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Sitka Small", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label19.Location = new System.Drawing.Point(30, 30);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(145, 24);
            this.label19.TabIndex = 11;
            this.label19.Text = "Gardian\'s Name";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.M_name);
            this.groupBox6.Controls.Add(this.M_nic);
            this.groupBox6.Controls.Add(this.M_co_no);
            this.groupBox6.Controls.Add(this.label14);
            this.groupBox6.Controls.Add(this.label15);
            this.groupBox6.Controls.Add(this.label16);
            this.groupBox6.Location = new System.Drawing.Point(39, 198);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(517, 170);
            this.groupBox6.TabIndex = 2;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Mother\'s Deatils";
            // 
            // M_name
            // 
            this.M_name.Location = new System.Drawing.Point(195, 21);
            this.M_name.Multiline = true;
            this.M_name.Name = "M_name";
            this.M_name.Size = new System.Drawing.Size(316, 63);
            this.M_name.TabIndex = 22;
            // 
            // M_nic
            // 
            this.M_nic.Location = new System.Drawing.Point(195, 91);
            this.M_nic.Name = "M_nic";
            this.M_nic.Size = new System.Drawing.Size(171, 31);
            this.M_nic.TabIndex = 21;
            // 
            // M_co_no
            // 
            this.M_co_no.Location = new System.Drawing.Point(195, 133);
            this.M_co_no.MaxLength = 10;
            this.M_co_no.Name = "M_co_no";
            this.M_co_no.Size = new System.Drawing.Size(171, 31);
            this.M_co_no.TabIndex = 20;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Sitka Small", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label14.Location = new System.Drawing.Point(30, 135);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(146, 24);
            this.label14.TabIndex = 13;
            this.label14.Text = "Contact Number";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Sitka Small", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label15.Location = new System.Drawing.Point(30, 98);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(41, 24);
            this.label15.TabIndex = 12;
            this.label15.Text = "NIC";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Sitka Small", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label16.Location = new System.Drawing.Point(30, 30);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(138, 24);
            this.label16.TabIndex = 11;
            this.label16.Text = "Mother\'s Name";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.Fa_name);
            this.groupBox5.Controls.Add(this.Fa_nic);
            this.groupBox5.Controls.Add(this.Fa_co_no);
            this.groupBox5.Controls.Add(this.label13);
            this.groupBox5.Controls.Add(this.label12);
            this.groupBox5.Controls.Add(this.label11);
            this.groupBox5.Location = new System.Drawing.Point(39, 27);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(517, 170);
            this.groupBox5.TabIndex = 1;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Father\'s Deatils";
            // 
            // Fa_name
            // 
            this.Fa_name.Location = new System.Drawing.Point(195, 21);
            this.Fa_name.Multiline = true;
            this.Fa_name.Name = "Fa_name";
            this.Fa_name.Size = new System.Drawing.Size(316, 63);
            this.Fa_name.TabIndex = 22;
            // 
            // Fa_nic
            // 
            this.Fa_nic.Location = new System.Drawing.Point(195, 91);
            this.Fa_nic.Name = "Fa_nic";
            this.Fa_nic.Size = new System.Drawing.Size(171, 31);
            this.Fa_nic.TabIndex = 21;
            // 
            // Fa_co_no
            // 
            this.Fa_co_no.Location = new System.Drawing.Point(195, 133);
            this.Fa_co_no.MaxLength = 10;
            this.Fa_co_no.Name = "Fa_co_no";
            this.Fa_co_no.Size = new System.Drawing.Size(171, 31);
            this.Fa_co_no.TabIndex = 20;
            this.Fa_co_no.TextChanged += new System.EventHandler(this.textBox8_TextChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Sitka Small", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label13.Location = new System.Drawing.Point(30, 135);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(146, 24);
            this.label13.TabIndex = 13;
            this.label13.Text = "Contact Number";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Sitka Small", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label12.Location = new System.Drawing.Point(30, 98);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(41, 24);
            this.label12.TabIndex = 12;
            this.label12.Text = "NIC";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Sitka Small", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label11.Location = new System.Drawing.Point(30, 30);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(132, 24);
            this.label11.TabIndex = 11;
            this.label11.Text = "Father\'s Name";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.h_no);
            this.groupBox3.Controls.Add(this.m_no);
            this.groupBox3.Controls.Add(this.email);
            this.groupBox3.Controls.Add(this.address);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.groupBox3.Location = new System.Drawing.Point(18, 305);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(577, 263);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Contact Details";
            // 
            // h_no
            // 
            this.h_no.Location = new System.Drawing.Point(177, 208);
            this.h_no.MaxLength = 10;
            this.h_no.Name = "h_no";
            this.h_no.Size = new System.Drawing.Size(171, 31);
            this.h_no.TabIndex = 19;
            // 
            // m_no
            // 
            this.m_no.Location = new System.Drawing.Point(177, 169);
            this.m_no.MaxLength = 10;
            this.m_no.Name = "m_no";
            this.m_no.Size = new System.Drawing.Size(171, 31);
            this.m_no.TabIndex = 18;
            // 
            // email
            // 
            this.email.Location = new System.Drawing.Point(177, 131);
            this.email.Name = "email";
            this.email.Size = new System.Drawing.Size(394, 31);
            this.email.TabIndex = 17;
            // 
            // address
            // 
            this.address.Location = new System.Drawing.Point(177, 39);
            this.address.Multiline = true;
            this.address.Name = "address";
            this.address.Size = new System.Drawing.Size(394, 81);
            this.address.TabIndex = 16;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Sitka Small", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label10.Location = new System.Drawing.Point(22, 210);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(116, 24);
            this.label10.TabIndex = 10;
            this.label10.Text = "Home phone";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Sitka Small", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label9.Location = new System.Drawing.Point(22, 175);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(124, 24);
            this.label9.TabIndex = 9;
            this.label9.Text = "Mobile Phone";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Sitka Small", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label8.Location = new System.Drawing.Point(22, 136);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(60, 24);
            this.label8.TabIndex = 8;
            this.label8.Text = "Email";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Sitka Small", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(22, 32);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(79, 24);
            this.label7.TabIndex = 7;
            this.label7.Text = "Address";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.DOB);
            this.groupBox2.Controls.Add(this.female);
            this.groupBox2.Controls.Add(this.male);
            this.groupBox2.Controls.Add(this.L_name);
            this.groupBox2.Controls.Add(this.F_name);
            this.groupBox2.Controls.Add(this.gender);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.groupBox2.Location = new System.Drawing.Point(18, 86);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(577, 210);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Basic Details";
            // 
            // DOB
            // 
            this.DOB.Font = new System.Drawing.Font("Sitka Heading", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.DOB.Location = new System.Drawing.Point(177, 115);
            this.DOB.Name = "DOB";
            this.DOB.Size = new System.Drawing.Size(281, 28);
            this.DOB.TabIndex = 18;
            // 
            // female
            // 
            this.female.AutoSize = true;
            this.female.Font = new System.Drawing.Font("Sitka Heading", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.female.ForeColor = System.Drawing.SystemColors.ControlText;
            this.female.Location = new System.Drawing.Point(285, 152);
            this.female.Name = "female";
            this.female.Size = new System.Drawing.Size(80, 27);
            this.female.TabIndex = 17;
            this.female.TabStop = true;
            this.female.Text = "Female";
            this.female.UseVisualStyleBackColor = true;
            // 
            // male
            // 
            this.male.AutoSize = true;
            this.male.Font = new System.Drawing.Font("Sitka Heading", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.male.ForeColor = System.Drawing.SystemColors.ControlText;
            this.male.Location = new System.Drawing.Point(177, 151);
            this.male.Name = "male";
            this.male.Size = new System.Drawing.Size(63, 27);
            this.male.TabIndex = 16;
            this.male.TabStop = true;
            this.male.Text = "Male";
            this.male.UseVisualStyleBackColor = true;
            // 
            // L_name
            // 
            this.L_name.Location = new System.Drawing.Point(177, 74);
            this.L_name.Name = "L_name";
            this.L_name.Size = new System.Drawing.Size(394, 31);
            this.L_name.TabIndex = 15;
            // 
            // F_name
            // 
            this.F_name.Location = new System.Drawing.Point(177, 36);
            this.F_name.Name = "F_name";
            this.F_name.Size = new System.Drawing.Size(394, 31);
            this.F_name.TabIndex = 14;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Sitka Small", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(22, 111);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(120, 24);
            this.label5.TabIndex = 5;
            this.label5.Text = "Date of Birth";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Sitka Small", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(22, 74);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 24);
            this.label4.TabIndex = 4;
            this.label4.Text = "Last Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Sitka Small", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(22, 36);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(104, 24);
            this.label3.TabIndex = 3;
            this.label3.Text = "First Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Cooper Black", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label1.Location = new System.Drawing.Point(295, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(507, 55);
            this.label1.TabIndex = 1;
            this.label1.Text = "Skills International";
            // 
            // Logout_link
            // 
            this.Logout_link.AutoSize = true;
            this.Logout_link.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Logout_link.Location = new System.Drawing.Point(12, 9);
            this.Logout_link.Name = "Logout_link";
            this.Logout_link.Size = new System.Drawing.Size(59, 21);
            this.Logout_link.TabIndex = 2;
            this.Logout_link.TabStop = true;
            this.Logout_link.Text = "Logout";
            this.Logout_link.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.Logout_link_LinkClicked);
            // 
            // Exit_link
            // 
            this.Exit_link.AutoSize = true;
            this.Exit_link.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Exit_link.Location = new System.Drawing.Point(1242, 684);
            this.Exit_link.Name = "Exit_link";
            this.Exit_link.Size = new System.Drawing.Size(34, 21);
            this.Exit_link.TabIndex = 3;
            this.Exit_link.TabStop = true;
            this.Exit_link.Text = "Exit";
            this.Exit_link.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.Exit_link_LinkClicked);
            // 
            // gender
            // 
            this.gender.AutoSize = true;
            this.gender.Font = new System.Drawing.Font("Sitka Small", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.gender.Location = new System.Drawing.Point(22, 153);
            this.gender.Name = "gender";
            this.gender.Size = new System.Drawing.Size(70, 24);
            this.gender.TabIndex = 6;
            this.gender.Text = "Gender";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1308, 749);
            this.Controls.Add(this.Exit_link);
            this.Controls.Add(this.Logout_link);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.regex);
            this.Name = "Form2";
            this.Text = "Student Registration - Skills International";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.regex.ResumeLayout(false);
            this.regex.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox regex;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label load_combo;
        private System.Windows.Forms.TextBox Fa_co_no;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox h_no;
        private System.Windows.Forms.TextBox m_no;
        private System.Windows.Forms.TextBox email;
        private System.Windows.Forms.TextBox address;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox L_name;
        private System.Windows.Forms.TextBox F_name;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox M_name;
        private System.Windows.Forms.TextBox M_nic;
        private System.Windows.Forms.TextBox M_co_no;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox Fa_name;
        private System.Windows.Forms.TextBox Fa_nic;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TextBox G_name;
        private System.Windows.Forms.TextBox G_nic;
        private System.Windows.Forms.TextBox G_co_no;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button delete2;
        private System.Windows.Forms.Button clear2;
        private System.Windows.Forms.Button update2;
        private System.Windows.Forms.Button reg2;
        private System.Windows.Forms.LinkLabel Logout_link;
        private System.Windows.Forms.LinkLabel Exit_link;
        private System.Windows.Forms.ComboBox reg_no;
        private System.Windows.Forms.DateTimePicker DOB;
        private System.Windows.Forms.RadioButton female;
        private System.Windows.Forms.RadioButton male;
        private System.Windows.Forms.Label gender;
    }
}