﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.Data.SqlClient;

namespace School
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-GRR1JML\SQLEXPRESS;Initial Catalog=Student;Integrated Security=True");
        SqlDataAdapter sqlda = new SqlDataAdapter();
        SqlCommand cmd = new SqlCommand();
        string gdr;

        public const string motif = @"^([0-9]{10})$";
        public static bool IsPhoneNbr(string number)
        {
            if (number != null) return Regex.IsMatch(number, motif);
            else return false;
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            try
            {


                reg_no.Items.Clear();
                conn.Open();
                string load_reg = "Select regNo from Registrations ORDER BY regNo ";
                sqlda = new SqlDataAdapter(load_reg, conn);
                DataTable dt = new DataTable();
                sqlda.Fill(dt);
                conn.Close();
                foreach(DataRow row1 in dt.Rows)
                    {
                    reg_no.Items.Add(row1["regNo"]);
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
            


        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void Exit_link_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            DialogResult any = MessageBox.Show("Do You Really Want To Exit !", "Exit", MessageBoxButtons.YesNo, 
                MessageBoxIcon.Question);
            if (DialogResult.Yes == any)
            {
                Application.Exit();

            }

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void reg_no_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                String si = reg_no.SelectedItem.ToString();
                conn.Open();
                String query = "Select * From Registrations Where regNo ='" +si+ "'";
                cmd = new SqlCommand(query, conn);
                SqlDataReader R = cmd.ExecuteReader();

                while(R.Read())
                {
                    F_name.Text = R.GetValue(1).ToString();
                    L_name.Text = R.GetValue(2).ToString();
                    DOB.Text = R.GetValue(3).ToString();
                    male .Text = R.GetValue(4).ToString();
                    female.Text = R.GetValue(5).ToString();
                    address.Text = R.GetValue(6).ToString();
                    email.Text = R.GetValue(7).ToString();
                    m_no.Text = R.GetValue(8).ToString();
                    h_no.Text = R.GetValue(9).ToString();
                    Fa_name.Text = R.GetValue(10).ToString();
                    Fa_nic.Text = R.GetValue(11).ToString();
                    Fa_co_no.Text = R.GetValue(12).ToString();
                    M_name.Text = R.GetValue(13).ToString();
                    M_nic.Text = R.GetValue(14).ToString();
                    M_co_no.Text = R.GetValue(15).ToString();
                    G_name.Text = R.GetValue(16).ToString();
                    G_nic.Text = R.GetValue(17).ToString();
                    G_co_no.Text = R.GetValue(18).ToString();
                    


                }
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }





        }

        private void Logout_link_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            DialogResult any = MessageBox.Show("Do You Want To Logout ?", "??", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (DialogResult.Yes == any)
            {
                Form1 frm1 = new Form1();
                this.Hide();
                frm1.Show();

            }

        }

        private void clear2_Click(object sender, EventArgs e)
        {
            {
                F_name.Clear();
                L_name.Clear();
                DOB.Text = "";
                male.Checked = false;
                female.Checked = false;
                address.Clear();
                email.Clear();
                m_no.Clear();
                h_no.Clear();
                Fa_name.Clear();
                Fa_nic.Clear();
                Fa_co_no.Clear();
                M_name.Clear();
                M_nic.Clear();
                M_co_no.Clear();
                G_name.Clear();
                G_nic.Clear();
                G_co_no.Clear();

                clear2.Text = "";
                clear2.Focus();

            }

        }

        private void delete2_Click(object sender, EventArgs e)
        {
            try
            {
                conn.Open();
                string sqldelete = "delete from Registrations where RegNo='" + delete2.Text + "'";
                SqlCommand com = new SqlCommand(sqldelete, conn);
                int v = com.ExecuteNonQuery();
                if (MessageBox.Show("Are you sure,Do you really want to delete this record", "Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    MessageBox.Show("Record Deleted Successfully"); 
                    Application.Exit();
                }
                MessageBox.Show("Record Deleted Successfully");
                F_name.Clear();
                L_name.Clear();
                DOB.Text = "";
                male.Checked = false;
                female.Checked = false;
                address.Clear();
                email.Clear();
                m_no.Clear();
                h_no.Clear();
                Fa_name.Clear();
                Fa_nic.Clear();
                Fa_co_no.Clear();
                M_name.Clear();
                M_nic.Clear();
                M_co_no.Clear();
                G_name.Clear();
                G_nic.Clear();
                G_co_no.Clear();

                clear2.Text = "";
                clear2.Focus();


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                conn.Close();
            }




        }

        private void reg2_Click(object sender, EventArgs e)
        {
            string lp = h_no.Text;
            if (!IsPhoneNbr(lp))
            {
                MessageBox.Show("Invalid Land Phone Number");
                return;
            }
            string mp = m_no.Text;
            if (!IsPhoneNbr(mp))
            {
                MessageBox.Show("Invalid Mobile Phone Number");
                return;
            }
            string fcn = Fa_co_no.Text;
            if (!IsPhoneNbr(fcn))
            {
                MessageBox.Show("Invalid Fathers Contact Number");
                return;
            }
            string mcn = M_co_no.Text;
            if (!IsPhoneNbr(mcn))
            {
                MessageBox.Show("Invalid Mothers Contact Number");
                return;

            }
            string gcn = G_co_no.Text;
            if (!IsPhoneNbr(gcn))
            {
                MessageBox.Show("Invalid Gardian Contact Number");
                return;

            }
            
            try
            {
                if (male.Checked)
                {
                    gdr= "Male";
                }
                else if (female.Checked)
                {
                    gdr = "Female";
                }
                else
                {
                    MessageBox.Show("Select the gender");
                }


                conn.Open();
                string sql = "insert into Registrations (regNo,firstname,lastname,dateOfBirth,gender,address,email,mobilePhone,homePhone,faName,faNic,facontactNo,mName,mNic,mcontactNo,gName,gNic,gcontactNo)values('" + reg_no.Text + "','" + F_name.Text + "','" + L_name.Text + "','" + DOB.Value + "','" + gdr + "','" + address.Text + "','" + email.Text + "','" + m_no + "','" + h_no + "','" + Fa_name.Text + "','" + Fa_nic.Text + "','" + Fa_co_no + "','" + M_name.Text + "','" + M_nic.Text + "','" + M_co_no + G_name.Text + "','" + G_nic.Text + "','" + G_co_no + "')";
                SqlCommand com = new SqlCommand(sql, conn);
                com.ExecuteNonQuery();
                MessageBox.Show("Record Added Successfully");
                F_name.Clear();
                L_name.Clear();
                DOB.Text = "";
                male.Checked = false;
                female.Checked = false;
                address.Clear();
                email.Clear();
                m_no.Clear();
                h_no.Clear();
                Fa_name.Clear();
                Fa_nic.Clear();
                Fa_co_no.Clear();
                M_name.Clear();
                M_nic.Clear();
                M_co_no.Clear();
                G_name.Clear();
                G_nic.Clear();
                G_co_no.Clear();

                clear2.Text = "";
                clear2.Focus();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }
            
        }

        private void update2_Click(object sender, EventArgs e)
        {

            try
            {
                if (male.Checked)
                {
                    gdr = "Male";
                }
                else
                {
                    gdr = "Female";
                }

                conn.Open();
                string sqlupdate = "update Registrations set firstname='" + F_name.Text + "',lastname='" + L_name.Text + "',dateOfBirth='" + DOB.Value + "',gender='" + gdr+ "',address='" + address.Text + "',email='" + email.Text + "',mobileNo='" + m_no.Text + "',homePhone='" + h_no.Text + "',faName='" + Fa_name.Text + "',faNic='" + Fa_nic.Text + "',facontactNo='" + Fa_co_no.Text + "',mName='" + M_name.Text + "',mNicC='" + M_nic.Text + "',mcontactNo='" + M_co_no.Text + "',gName='" + G_name.Text + "',gNicC='" + G_nic.Text + "',gcontactNo='" + G_co_no.Text + "'where RegNo = '" + reg_no.Text + "'";
                SqlCommand com = new SqlCommand(sqlupdate, conn);
                com.ExecuteNonQuery();

                
                MessageBox.Show("Record Updated Successfully");
                F_name.Clear();
                L_name.Clear();
                DOB.Text = "";
                male.Checked = false;
                female.Checked = false;
                address.Clear();
                email.Clear();
                m_no.Clear();
                h_no.Clear();
                Fa_name.Clear();
                Fa_nic.Clear();
                Fa_co_no.Clear();
                M_name.Clear();
                M_nic.Clear();
                M_co_no.Clear();
                G_name.Clear();
                G_nic.Clear();
                G_co_no.Clear();

                clear2.Text = "";
                clear2.Focus();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();

            }
            
        }


    }
}

