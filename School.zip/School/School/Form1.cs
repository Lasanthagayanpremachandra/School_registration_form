﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
namespace School
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure,Do you really want to Exit", "Exit Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection sqlcon = new SqlConnection(@"Data Source=DESKTOP-GRR1JML\SQLEXPRESS;Initial Catalog=loginform;Integrated Security=True");
            string query = "Select * from tb_login Where username = '" + user_name.Text.Trim() + "'and password = '" + pass.Text.Trim() + "'";
            SqlDataAdapter sda = new SqlDataAdapter(query, sqlcon);
            DataTable dtbl = new DataTable();
            sda.Fill(dtbl);

            if(dtbl.Rows.Count==1)
            {
                Form2 objForm2 = new Form2();
                this.Hide();
                objForm2.Show();
            }
            else
            {
                MessageBox.Show("Invalid Login credentials,please check Username and Password and try again");
            }

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void clear_Click(object sender, EventArgs e)
        {
            pass.Clear();
            user_name.Clear();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }
    }
}
